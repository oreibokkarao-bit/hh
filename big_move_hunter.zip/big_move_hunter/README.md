# Big Move Hunter v0.1 (Binance USDT-M, Thonny/macOS)

Run either:
- `python -m src.main` (recommended, from project root), or
- `python run.py` (convenience launcher).

See `config/settings.yaml` to tune thresholds/weights, risk, decay, and alerts.
