# --- Thonny / direct-run bootstrap: add project root to sys.path BEFORE package imports ---
import os, sys
if __package__ in (None, ""):
    _ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    if _ROOT not in sys.path:
        sys.path.insert(0, _ROOT)
# -----------------------------------------------------------------------------------------

import asyncio
import json
import math
from collections import deque
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
import websockets
import yaml

# absolute imports (will succeed whether run via run.py or directly in Thonny)
from src.utils.backoff_http import HttpClient
from src.utils.rate_limit import TokenBucket
from src.utils.timeutil import utc_now_str
from src.utils.notifiers import mac_beep, telegram_send

BINANCE_FUTS_WS = "wss://fstream.binance.com/stream"
BINANCE_FUTS_REST = "https://fapi.binance.com"
BINANCE_SPOT_REST = "https://api.binance.com"


@dataclass
class Params:
    top_symbols: int
    min_24h_quote_usd: float
    lookback_minutes: int
    spark_thr: float
    ignition_thr: float
    weights: dict
    atr_period: int
    atr_mult_sl: float
    tp_r: List[float]
    decay_seconds: int


class BigMoveHunter:
    def __init__(self, cfg_path: str):
        self.cfg = yaml.safe_load(open(cfg_path))
        g = self.cfg["general"]; th = self.cfg["thresholds"]; w = self.cfg["weights"]; r = self.cfg["risk"]
        self.params = Params(
            top_symbols=int(g["top_symbols"]),
            min_24h_quote_usd=float(g["min_24h_quote_usd"]),
            lookback_minutes=int(g["lookback_minutes"]),
            spark_thr=float(th["spark_score"]),
            ignition_thr=float(th["ignition_score"]),
            weights=w,
            atr_period=int(r["atr_period"]),
            atr_mult_sl=float(r["atr_multiplier_sl"]),
            tp_r=[float(x) for x in r["tp_r"]],
            decay_seconds=int(g["decay_seconds"]),
        )
        self.lr_futs = HttpClient(BINANCE_FUTS_REST)
        self.lr_spot = HttpClient(BINANCE_SPOT_REST)
        self.token_bucket = TokenBucket(rate_per_sec=8, capacity=16)
        self.baselines: Dict[str, deque] = {}
        self.volumes: Dict[str, deque] = {}
        self.signals: Dict[str, dict] = {}
        self._symbols: List[str] = []

    # -------------------- Discovery + Seeding --------------------
    def _get_usdt_perps(self) -> List[str]:
        """
        Robust discovery of top USDT-M perps by 24h quote volume.
        Handles unexpected JSON types and falls back to per-symbol queries.
        """
        # exchangeInfo → all trading USDT perps
        self.token_bucket.consume()
        ex = self.lr_futs.get("/fapi/v1/exchangeInfo").json()
        symbols_all: List[str] = []
        if isinstance(ex, dict):
            for s in ex.get("symbols", []):
                if s.get("contractType") == "PERPETUAL" and s.get("quoteAsset") == "USDT" and s.get("status") == "TRADING":
                    sym = s.get("symbol")
                    if isinstance(sym, str):
                        symbols_all.append(sym)

        # bulk 24hr ticker
        qmap: Dict[str, float] = {}
        try:
            self.token_bucket.consume()
            t24 = self.lr_futs.get("/fapi/v1/ticker/24hr").json()
        except Exception:
            t24 = None

        if isinstance(t24, list):
            for t in t24:
                try:
                    sym = t.get("symbol")
                    if sym in symbols_all:
                        qmap[sym] = float(t.get("quoteVolume", 0.0) or 0.0)
                except Exception:
                    pass
        else:
            # fallback: per-symbol (rate limited)
            cap = max(self.params.top_symbols * 3, 200)
            for sym in symbols_all[:cap]:
                try:
                    self.token_bucket.consume()
                    one = self.lr_futs.get("/fapi/v1/ticker/24hr", params={"symbol": sym}).json()
                    if isinstance(one, dict):
                        qmap[sym] = float(one.get("quoteVolume", 0.0) or 0.0)
                except Exception:
                    qmap[sym] = 0.0

        filtered = [s for s in symbols_all if qmap.get(s, 0.0) >= self.params.min_24h_quote_usd]
        filtered.sort(key=lambda x: qmap.get(x, 0.0), reverse=True)
        return [s.lower() for s in filtered[: self.params.top_symbols]]

    def _seed_history(self, sym: str):
        closes = deque(maxlen=self.params.lookback_minutes)
        vols = deque(maxlen=self.params.lookback_minutes)
        try:
            self.token_bucket.consume()
            kl = self.lr_futs.get("/fapi/v1/klines",
                                  params={"symbol": sym.upper(), "interval": "1m", "limit": self.params.lookback_minutes}).json()
            if isinstance(kl, list) and kl:
                for row in kl:
                    try:
                        closes.append(float(row[4])); vols.append(float(row[5]))
                    except Exception:
                        continue
        except Exception:
            kl = None
        if len(closes) < 3:
            try:
                self.token_bucket.consume()
                p = self.lr_futs.get("/fapi/v1/ticker/price", params={"symbol": sym.upper()}).json()
                price = float(p.get("price", 0.0)) if isinstance(p, dict) else 0.0
            except Exception:
                price = 0.0
            if price <= 0.0: price = 1.0
            for _ in range(self.params.lookback_minutes):
                closes.append(price); vols.append(0.0)
        self.baselines[sym] = closes
        self.volumes[sym] = vols

    # -------------------- Metrics + Scoring --------------------
    def _calc_zscores(self, sym: str, new_close: float, new_vol: float) -> Tuple[float, float]:
        closes = self.baselines[sym]; vols = self.volumes[sym]
        if len(closes) < 3: return 0.0, 0.0
        pct = np.diff(np.array(closes)) / np.array(closes)[:-1]
        mu_p, sd_p = float(np.mean(pct)), float(np.std(pct) + 1e-9)
        last_p = (new_close - closes[-1]) / (closes[-1] + 1e-9)
        z_p = (last_p - mu_p) / sd_p
        mu_v, sd_v = float(np.mean(vols)), float(np.std(vols) + 1e-9)
        z_v = (new_vol - mu_v) / sd_v
        return z_p, z_v

    def _atr(self, sym: str) -> float:
        try:
            self.token_bucket.consume()
            kl = self.lr_futs.get("/fapi/v1/klines",
                                  params={"symbol": sym.upper(), "interval": "1m", "limit": max(30, self.params.atr_period + 2)}).json()
            if not (isinstance(kl, list) and len(kl) >= self.params.atr_period + 2):
                raise ValueError("bad klines")
            highs = np.array([float(k[2]) for k in kl]); lows = np.array([float(k[3]) for k in kl]); closes = np.array([float(k[4]) for k in kl])
            prev_close = np.concatenate([[closes[0]], closes[:-1]])
            tr = np.maximum.reduce([highs - lows, np.abs(highs - prev_close), np.abs(lows - prev_close)])
            alpha = 1.0 / self.params.atr_period; atr = 0.0
            for t in tr: atr = alpha * t + (1 - alpha) * atr
            return float(atr)
        except Exception:
            try:
                self.token_bucket.consume()
                p = self.lr_futs.get("/fapi/v1/ticker/price", params={"symbol": sym.upper()}).json()
                price = float(p.get("price", 0.0)) if isinstance(p, dict) else 0.0
            except Exception:
                price = 0.0
            if price <= 0.0: price = 1.0
            return 0.002 * price

    def _deep_analysis_and_score(self, sym: str, price_z: float, vol_z: float) -> Tuple[float, dict]:
        # OI change %
        oi_pct = 0.0
        try:
            self.token_bucket.consume()
            oi = self.lr_futs.get("/futures/data/openInterestHist",
                                  params={"symbol": sym.upper(), "period": "5m", "limit": 12}).json()
            if isinstance(oi, list) and len(oi) >= 2:
                a = float(oi[0]["sumOpenInterest"]); b = float(oi[-1]["sumOpenInterest"])
                oi_pct = (b / max(a, 1e-9) - 1.0) * 100.0
        except Exception:
            pass
        oi_z = max(-2.0, min(2.0, (oi_pct - 2.0) / 5.0))

        # funding
        fr = 0.0
        try:
            self.token_bucket.consume()
            f = self.lr_futs.get("/fapi/v1/premiumIndex", params={"symbol": sym.upper()}).json()
            if isinstance(f, dict): fr = float(f.get("lastFundingRate", 0.0) or 0.0)
        except Exception:
            pass
        fr_score = -1.0 if abs(fr) > 0.001 else 0.5

        # spot vs futures participation
        spot_vol = 0.0
        try:
            self.token_bucket.consume()
            sp = self.lr_spot.get("/api/v3/klines", params={"symbol": sym.upper(), "interval": "5m", "limit": 12}).json()
            if isinstance(sp, list):
                spot_vol = sum(float(r[5]) for r in sp if isinstance(r, list) and len(r) > 5)
        except Exception:
            pass
        fut_vol = sum(list(self.volumes[sym])[-12:]) if len(self.volumes[sym]) >= 12 else sum(self.volumes[sym])
        ratio = fut_vol / max(spot_vol, 1e-9)
        spot_lead = 1.0 if ratio < 4.0 else -1.0

        w = self.params.weights
        final_score = (price_z * w["price_change_z"] + vol_z * w["volume_z"] + oi_z * w["oi_change_z"]
                       + spot_lead * w["spot_leadership"] + fr_score * w["funding_rate_score"])
        detail = {"oi_change_pct": round(oi_pct, 3), "funding_rate": fr, "fut_spot_vol_ratio": round(ratio, 3)}
        return float(final_score), detail

    # -------------------- WS + Scheduler --------------------
    async def _ws_loop(self):
        while True:
            try:
                if not self._symbols:
                    await asyncio.sleep(2.0); continue
                streams = "/".join([f"{s}@kline_1m" for s in self._symbols])
                url = f"{BINANCE_FUTS_WS}?streams={streams}"
                async with websockets.connect(url, ping_interval=15, ping_timeout=15) as ws:
                    while True:
                        j = json.loads(await ws.recv())
                        d = j.get("data"); 
                        if not isinstance(d, dict): continue
                        k = d.get("k"); 
                        if not isinstance(k, dict): continue
                        if not k.get("x"): continue  # candle close only

                        sym = str(k.get("s", "")).lower()
                        try:
                            close = float(k.get("c", 0.0)); vol = float(k.get("v", 0.0))
                        except Exception:
                            continue

                        if sym not in self.baselines: self._seed_history(sym)
                        z_p, z_v = self._calc_zscores(sym, close, vol)
                        self.baselines[sym].append(close); self.volumes[sym].append(vol)

                        spark = 0.6 * z_p + 0.4 * z_v
                        now = datetime.now(timezone.utc).timestamp()

                        if sym in self.signals and now - self.signals[sym]["ts"] > self.params.decay_seconds:
                            self.signals.pop(sym, None)

                        if spark >= self.params.spark_thr:
                            score, detail = self._deep_analysis_and_score(sym, z_p, z_v)
                            if score >= self.params.ignition_thr:
                                atr = self._atr(sym); entry = close
                                sl = entry - self.params.atr_mult_sl * atr
                                risk = max(entry - sl, 1e-9)
                                tps = [entry + r * risk for r in self.params.tp_r]
                                self.signals[sym] = {
                                    "status": "IGNITED", "symbol": sym.upper(), "score": round(score, 2),
                                    "entry": round(entry, 6), "sl": round(sl, 6),
                                    "tp": [round(x, 6) for x in tps], "detail": detail,
                                    "ts": now, "when_utc": utc_now_str()
                                }
                                mac_beep()
                                telegram_send(f"IGNITED {sym.upper()} score {round(score,2)} entry {entry:.6f} SL {sl:.6f} TP1 {tps[0]:.6f}")
            except Exception:
                await asyncio.sleep(2.0)

    async def _symbols_refresher(self):
        while True:
            try:
                syms = self._get_usdt_perps()
                for s in syms:
                    if s not in self.baselines: self._seed_history(s)
                self._symbols = syms
            except Exception:
                pass
            await asyncio.sleep(int(self.cfg["general"]["symbols_refresh_min"]) * 60)

    async def run(self):
        self._symbols = self._get_usdt_perps()
        for s in self._symbols:
            if s not in self.baselines: self._seed_history(s)
        await asyncio.gather(self._ws_loop(), self._symbols_refresher())


# -------------------- Minimal Thonny-safe table --------------------
def fmt_table(signals: Dict[str, dict]) -> str:
    headers = ["Status","Symbol","Score","Entry","SL","TP1","TP2","TP3","UTC"]
    rows = []
    for _, sig in sorted(signals.items(), key=lambda kv: kv[1]["score"], reverse=True)[:10]:
        tps = sig["tp"]
        rows.append([sig["status"], sig["symbol"], f"{sig['score']:.2f}", f"{sig['entry']:.6f}",
                     f"{sig['sl']:.6f}", f"{tps[0]:.6f}", f"{tps[1]:.6f}", f"{tps[2]:.6f}", sig["when_utc"]])
    if not rows:
        rows = [["(warming)", "—", "—", "—", "—", "—", "—", "—", "waiting for first sparks..."]]
    widths = [max(len(str(x)) for x in col) for col in zip(*([headers] + rows))]
    out = []
    out.append(" | ".join(h.ljust(w) for h, w in zip(headers, widths)))
    out.append("-+-".join("-" * w for w in widths))
    for r in rows:
        out.append(" | ".join(str(c).ljust(w) for c, w in zip(r, widths)))
    return "\n".join(out)
