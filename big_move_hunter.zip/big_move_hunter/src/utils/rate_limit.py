import time
import threading

class TokenBucket:
    def __init__(self, rate_per_sec: float, capacity: int):
        self.rate = rate_per_sec
        self.capacity = capacity
        self.tokens = capacity
        self.lock = threading.Lock()
        self.timestamp = time.monotonic()

    def consume(self, amount: int = 1) -> None:
        while True:
            with self.lock:
                now = time.monotonic()
                delta = now - self.timestamp
                self.timestamp = now
                self.tokens = min(self.capacity, self.tokens + delta * self.rate)
                if self.tokens >= amount:
                    self.tokens -= amount
                    return
            time.sleep(0.01)
