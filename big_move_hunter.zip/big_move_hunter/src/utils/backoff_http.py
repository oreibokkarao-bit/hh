import httpx
import time
from typing import Optional, Dict, Any

class HttpClient:
    def __init__(self, base_url: str = "", timeout: float = 10.0, max_retries: int = 5):
        self.base_url = base_url
        self.timeout = timeout
        self.max_retries = max_retries
        self.client = httpx.Client(base_url=base_url, timeout=timeout, http2=True)

    def get(self, path: str, params: Optional[Dict[str, Any]] = None) -> httpx.Response:
        delay = 0.25
        for attempt in range(self.max_retries):
            try:
                r = self.client.get(path if self.base_url else path, params=params)
                if r.status_code in (429, 500, 502, 503, 504):
                    raise httpx.HTTPError(f"Transient HTTP {r.status_code}")
                return r
            except Exception:
                if attempt == self.max_retries - 1:
                    raise
                time.sleep(delay)
                delay = min(delay * 2, 5.0)
        return r
