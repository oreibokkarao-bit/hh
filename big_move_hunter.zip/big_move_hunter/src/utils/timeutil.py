from datetime import datetime, timezone
import zoneinfo

IST_TZ = zoneinfo.ZoneInfo("Asia/Kolkata")

def utc_now_str():
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")

def ist_now_str():
    return datetime.now(timezone.utc).astimezone(IST_TZ).strftime("%Y-%m-%d %H:%M:%S")
