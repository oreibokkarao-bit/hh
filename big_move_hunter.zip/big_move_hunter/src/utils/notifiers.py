import os
import subprocess
import httpx

def mac_beep():
    try:
        if os.uname().sysname == "Darwin":
            subprocess.run(["afplay", "/System/Library/Sounds/Pop.aiff"], check=False)
    except Exception:
        pass

def telegram_send(text: str, bot_token: str = None, chat_id: str = None):
    token = bot_token or os.getenv("TELEGRAM_BOT_TOKEN", "")
    chat = chat_id or os.getenv("TELEGRAM_CHAT_ID", "")
    if not token or not chat:
        return False
    try:
        url = f"https://api.telegram.org/bot{token}/sendMessage"
        httpx.post(url, data={"chat_id": chat, "text": text})
        return True
    except Exception:
        return False
