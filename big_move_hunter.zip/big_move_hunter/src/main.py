import argparse
import asyncio
import os

from src.scanner.big_move_hunter import BigMoveHunter, fmt_table

async def printer(hunter: BigMoveHunter):
    """Thonny-safe printer (no terminal clear; non-blocking)."""
    last = None
    while True:
        table = fmt_table(hunter.signals)
        if table != last:
            print("\nBig Move Hunter v0.1 — Live Signals (top 10)")
            print(table)
            last = table
        await asyncio.sleep(1.0)  # <-- non-blocking (fixes event-loop stall)

async def run_all(cfg_path: str):
    hunter = BigMoveHunter(cfg_path)
    await asyncio.gather(hunter.run(), printer(hunter))

def main():
    parser = argparse.ArgumentParser(description="Big Move Hunter v0.1 (Binance USDT-M)")
    parser.add_argument("--config", default=os.path.join(os.path.dirname(__file__), "..", "config", "settings.yaml"))
    args = parser.parse_args()
    asyncio.run(run_all(args.config))

if __name__ == "__main__":
    main()
