import asyncio, logging
from typing import Dict, Any, List

class ConsoleUI:
    def __init__(self, config: Dict[str, Any], order_queue: asyncio.Queue):
        self.log = logging.getLogger(self.__class__.__name__)
        self.cfg = config
        self.q = order_queue
    async def run(self):
        self.log.info("ConsoleUI running.")
        while True:
            item = await self.q.get()
            approved: List[Dict[str, Any]] = item.get("approved", [])
            if not approved: continue
            print("\n=== Top Picks (Unified Spot — Binance + Bybit + Bitget) ===")
            for i, row in enumerate(approved, 1):
                print(f"{i:>2}. {row['symbol']:>12} | SIP {row['sip_score']:>6}")
            print("============================================================\n")
