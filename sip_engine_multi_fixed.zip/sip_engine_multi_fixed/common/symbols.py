
import re
from typing import Tuple

SEP_RE = re.compile(r"[-_/:\s]")
def unify_symbol(raw: str) -> str:
    if not raw: return raw
    return SEP_RE.sub("", raw).upper()

def split_base_quote(sym: str) -> Tuple[str, str]:
    s = unify_symbol(sym)
    for q in ("USDT","FDUSD","TUSD","USDC","BUSD","USD","BTC","ETH","TRY","EUR","BRL"):
        if s.endswith(q):
            return s[:-len(q)], q
    return s[:-4], s[-4:]
