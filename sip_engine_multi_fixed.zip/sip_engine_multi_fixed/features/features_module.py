
import pandas as pd
import numpy as np
from typing import List, Dict, Any

def resample_trades_to_ohlcv(trades: List[Dict[str, Any]], timeframe: str = '1h') -> pd.DataFrame:
    if not trades: return pd.DataFrame()
    df = pd.DataFrame(trades)
    df['T'] = pd.to_datetime(df['ts'], unit='ms')
    df.set_index('T', inplace=True)
    df['p'] = pd.to_numeric(df['price'])
    df['q'] = pd.to_numeric(df['qty'])
    ohlc = df['p'].resample(timeframe, label='left', closed='left').ohlc()
    volume = df['q'].resample(timeframe, label='left', closed='left').sum()
    ohlcv = ohlc.join(volume); ohlcv.rename(columns={'q':'volume'}, inplace=True)
    return ohlcv

def calculate_atr(ohlcv_df: pd.DataFrame, period: int = 14) -> pd.Series:
    high, low, close = ohlcv_df['high'], ohlcv_df['low'], ohlcv_df['close']
    tr1 = high - low
    tr2 = np.abs(high - close.shift(1))
    tr3 = np.abs(low - close.shift(1))
    true_range = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
    return true_range.ewm(alpha=1/period, adjust=False).mean()

def calculate_spot_cvd(trades: List[Dict[str, Any]]) -> pd.DataFrame:
    if not trades: return pd.DataFrame()
    rows = []; cvd_sum = 0.0; c = 0.0
    for tr in trades:
        qty = float(tr["qty"]); taker = tr.get("taker")
        if taker is None and "m" in tr: taker = "sell" if tr["m"] else "buy"
        signed = qty if taker == "buy" else -qty
        y = signed - c; t = cvd_sum + y; c = (t - cvd_sum) - y; cvd_sum = t
        rows.append({"timestamp": pd.to_datetime(tr["ts"], unit='ms'), "delta": signed, "cvd": cvd_sum})
    df = pd.DataFrame(rows); df.set_index("timestamp", inplace=True); return df

def calculate_ob_imbalance(book: Dict[str, Any], k_bps: int = 25) -> float:
    bids = book.get('bids', []); asks = book.get('asks', [])
    if not bids or not asks: return 0.5
    best_bid, best_ask = bids[0][0], asks[0][0]
    mid = (best_bid + best_ask) / 2.0
    if mid <= 0: return 0.5
    wlow, whi = mid*(1 - k_bps/10000), mid*(1 + k_bps/10000)
    bid_vol = sum(sz for p,sz in bids if p >= wlow)
    ask_vol = sum(sz for p,sz in asks if p <= whi)
    tot = bid_vol + ask_vol
    return 0.5 if tot == 0 else bid_vol / tot
