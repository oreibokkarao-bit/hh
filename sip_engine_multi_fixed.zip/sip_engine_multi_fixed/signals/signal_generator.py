
import asyncio, logging, pandas as pd
from typing import Dict, Any
from signals.signal_scorer import SignalScorer

class SignalGenerator:
    def __init__(self, config: Dict[str, Any], feature_queue: asyncio.Queue, signal_queue: asyncio.Queue):
        self.log = logging.getLogger(self.__class__.__name__)
        self.cfg = config
        self.q_feats = feature_queue
        self.q_out = signal_queue
        self.weights = self.cfg.get("signal_weights", {
            "stealth_features": {"cvd_slope_1m": 1.0},
            "ignition_features": {},
            "propulsion_features": {"ob_imbalance": 1.0},
            "sip_sub_scores": {"stealth": 0.6, "ignition": 0.0, "propulsion": 0.4},
        })
        self.scorer = SignalScorer(self.weights)
        self._latest: Dict[str, Dict[str, float]] = {}
        self.top_n = int(self.cfg.get("top_n", 15))
        self.emit_every_sec = int(self.cfg.get("signal_emit_sec", 5))

    async def run(self):
        self.log.info("SignalGenerator running.")
        consumer = asyncio.create_task(self._consume())
        emitter = asyncio.create_task(self._emit())
        await asyncio.gather(consumer, emitter)

    async def _consume(self):
        while True:
            item = await self.q_feats.get()
            self._latest[item["symbol"]] = item["features"]

    async def _emit(self):
        while True:
            await asyncio.sleep(self.emit_every_sec)
            if not self._latest: continue
            df = pd.DataFrame.from_dict(self._latest, orient="index")
            scores = self.scorer.calculate_sip_score(df).sort_values("sip_score", ascending=False)
            top = scores.head(self.top_n).reset_index().rename(columns={"index":"symbol"})
            await self.q_out.put({"scores": top})
