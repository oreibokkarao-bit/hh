
import asyncio
from typing import List, Dict, Any

class ExchangeConnector:
    name = "base"
    def __init__(self, config: Dict[str, Any]):
        self.cfg = config
    async def fetch_symbols(self) -> List[str]:
        raise NotImplementedError
    async def stream(self, out_queue: asyncio.Queue):
        raise NotImplementedError
