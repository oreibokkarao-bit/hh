
import asyncio, aiohttp, websockets, json, logging
from typing import List, Dict, Any
from data.exchange_base import ExchangeConnector
from common.symbols import unify_symbol
from common.rate_limiter import TokenBucket

REST = "https://api.bybit.com"
WS   = "wss://stream.bybit.com/v5/public/spot"

class BybitSpotConnector(ExchangeConnector):
    name = "bybit"
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.log = logging.getLogger(self.__class__.__name__)
        self.bucket = TokenBucket(rate_per_sec=4.0, burst=4)

    async def fetch_symbols(self) -> List[str]:
        params = {"category":"spot"}
        async with aiohttp.ClientSession() as s:
            async with s.get(f"{REST}/v5/market/instruments-info", params=params, timeout=20) as r:
                r.raise_for_status()
                data = await r.json()
        syms = [d["symbol"] for d in data.get("result",{}).get("list",[]) if d.get("status") == "Trading"]
        quotes = set(x.upper() for x in self.cfg.get("quote_whitelist", []))
        if quotes:
            flt = []
            for sym in syms:
                up = unify_symbol(sym)
                quote = None
                for q in ("USDT","FDUSD","TUSD","USDC","BUSD","USD","TRY","EUR","BRL","ETH","BTC"):
                    if up.endswith(q): quote = q; break
                if quote in quotes:
                    flt.append(up)
            syms = flt
        return sorted(set(unify_symbol(s) for s in syms))

    async def _ws_shard(self, symbols: List[str], out_queue: asyncio.Queue):
        url = WS
        topics = []
        for s in symbols:
            u = unify_symbol(s)
            topics.append(f"publicTrade.{u}")
            topics.append(f"orderbook.1.{u}")
        self.log.info(f"Bybit shard connect: {len(symbols)} syms / {len(topics)} topics")
        while True:
            try:
                async with websockets.connect(url, ping_interval=20, ping_timeout=20, max_size=2**22) as ws:
                    batch = int(self.cfg.get("bybit_topics_per_sub", 40))
                    for i in range(0, len(topics), batch):
                        args = topics[i:i+batch]
                        sub = {"op":"subscribe","args":args}
                        await self.bucket.take(1)
                        await ws.send(json.dumps(sub))
                        await asyncio.sleep(0.2)
                    async for raw in ws:
                        msg = json.loads(raw)
                        topic = msg.get("topic","")
                        if not topic: continue
                        if topic.startswith("publicTrade."):
                            sym = unify_symbol(topic.split(".")[1])
                            for t in msg.get("data", []):
                                taker = "buy" if str(t.get("S","Buy")).lower().startswith("buy") else "sell"
                                await out_queue.put({"type":"trade","symbol":sym,"ts":t.get("T") or t.get("ts"),
                                                     "price":float(t["p"]), "qty":float(t["v"]), "taker":taker,
                                                     "exchange": self.name})
                        elif topic.startswith("orderbook.1."):
                            sym = unify_symbol(topic.split(".")[2])
                            d = msg.get("data",{})
                            bids = [[float(x[0]), float(x[1])] for x in d.get("b",[])]
                            asks = [[float(x[0]), float(x[1])] for x in d.get("a",[])]
                            await out_queue.put({"type":"depth","symbol":sym,"exchange":self.name,"bids":bids,"asks":asks})
            except Exception as e:
                self.log.error(f"Bybit shard error: {e}. Reconnecting in 5s…")
                await asyncio.sleep(5)

    async def stream(self, out_queue: asyncio.Queue):
        all_syms: List[str] = self.cfg.get("_bybit_symbols_cache") or await self.fetch_symbols()
        self.cfg["_bybit_symbols_cache"] = all_syms
        per_socket = int(self.cfg.get("bybit_symbols_per_socket", 100))
        tasks = []
        for i in range(0, len(all_syms), per_socket):
            chunk = all_syms[i:i+per_socket]
            tasks.append(asyncio.create_task(self._ws_shard(chunk, out_queue)))
        await asyncio.gather(*tasks)
